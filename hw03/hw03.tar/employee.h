#pragma once 
#include <iostream>
#include <iomanip> 
#include <string>
#include "date.h"

using namespace std; 
/********************************************************
employee

object holding an info for a 'CS1C Employee'.
holds the info:
name, 
ID, 
phone number, 
age, 
gender, 
job title, 
salary, 
hire date. 
contains member functions that changes each of these 
data members, and a function to where all
the current data members are listed. 

constructor: initalizes data members.

non-default constructor: initializes data members with
different info from the default constructor,
is called when a bool is passed through the 
parameter
********************************************************/
class employee
{
public:
	string   name;     //name 
	long int ID;       //ID
	string   phoneNum; //phone number 
	int      age;      //age
	char     gender;   //gender
	string   jobTitle; //job title
	long int salary;   //salary
	date     hireDate; //hire date; an object of the date class
	
	employee(); //constructor

 	employee(bool which); //non-default constructor
	
	void print(); 

	void changeName();
	void changeID(); 
	void changePhoneNum();
	void changeAge();
	void changeGender();
	void changeJobTitle();
	void changeSalary();
	void changeHireDate();

};

