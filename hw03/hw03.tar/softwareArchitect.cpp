#include "softwareArchitect.h"
/***********************************************
softwareArchitect()(default constructor)

when object is created without parameters, will
initialize all data members with values labled
below
************************************************/
softwareArchitect::softwareArchitect() {
	name = "Alex Arch";
	ID = 88888;
	phoneNum = "819-123-4444";
	age = 31;
	gender = 'M';
	jobTitle = "Architect";
	salary = 323000;
	hireDate.month = 12;
	hireDate.day = 24;
	hireDate.year = 2009;
	deptNum = 5434222;
	supervisor = "Big Boss";
	raise = 5;
	experience = 4;
}
/**************************************************
softwareArchitect(bool which)(non-default constructor)

when object is created with a bool parameter, will
initalize all data members with values labeled
below
***************************************************/
softwareArchitect::softwareArchitect(bool which) {
	name = "Sally Designer";
	ID = 87878;
	phoneNum = "310-555-8888";
	age = 38;
	gender = 'F';
	jobTitle = "Architect";
	salary = 870123;
	hireDate.month = 2;
	hireDate.day = 8;
	hireDate.year = 2003;
	deptNum = 654322;
	supervisor = "Big Boss";
	raise = 8;
	experience = 11;
}
/********************************************************************************
softPrint

will print the private data members along with the data members from the employee
class
Name:
ID:
Phone #:
Age:
Gender:
Job Title:
Salary:
Hire Date:
Department Number:
Supervisor:
Raise(%):
Years of Experience:

pre: none
post: printss current values in all data members of object type 
      'softwareArchitect'
*********************************************************************************/
void softwareArchitect::softPrint() {
	print();
	cout << "Department Number:   " << deptNum << '\n';
	cout << "Supervisor:          " << supervisor << '\n';
	cout << "Raise(%):            " << raise << "%\n";
	cout << "Years of Experience: " << experience << " year(s)\n";
}
/********************************************************************
changeDeptNum

when called, prompts the user to change the value stored in 'deptNum'

-  pre: none
- post: new value stored in 'deptNum' data member
*********************************************************************/
void softwareArchitect::changeDeptNum() {
	cout << "Enter new Department #: ";
	cin >> deptNum;
}
/************************************************************************
changeSupervisor

when called, prompts the user to change the value stored in 'supervisor'

-  pre: none
- post: new value stored in 'supervisor' data member
*************************************************************************/
void softwareArchitect::changeSupervisor() {
	cout << "Enter new supervisor: ";
	getline(cin, supervisor);
}
/*******************************************************************
changeRaise

when called, prompts the user to change the value stored in 'raise'

-  pre: none
- post: new value stored in 'raise' data member
*******************************************************************/
void softwareArchitect::changeRaise() {
	cout << "Enter new raise(%): ";
	cin >> raise; 
}
/************************************************************************
changeExperience

when called, prompts the user to change the value stored in 'experience'

-  pre: none
- post: new value stored in 'experience' data member
*************************************************************************/
void softwareArchitect::changeExperience() {
	cout << "Enter new experience(in years): ";
	cin >> experience;
}