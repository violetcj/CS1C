#include <iostream>
#include <iomanip> 
#include <string>
#include "date.h"
using namespace std;

date::date(): month(00), day(00), year(0000)
{
}