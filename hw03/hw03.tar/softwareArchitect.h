#pragma once
#include "employee.h"
/*********************************************************************
softwareArchitect

base class: employee

derived from the employee class, class that holds more data members
relating to the profession this class represents:
deptNum (department number)
supervisor
raise
experience (years of experience)

dds on member functions that change these new data members, and a
modified print function.
changeDeptNum
changeSupervisor
changeRaise
changeExperience
softPrint

constructor:
initializes data members from both the employee class data members and
the ones written in this class

non-default constructor:
initializes data members differently, will be called when a bool value
is passed through as a parameter
***********************************************************************/
class softwareArchitect :
	public employee
{
public:

	softwareArchitect();           //constructor
	softwareArchitect(bool which); //non-default constructor

	void softPrint();

	void changeDeptNum(); 
    void changeSupervisor();
    void changeRaise();
    void changeExperience();

private: 
	int deptNum;       //department number(int)
	string supervisor; //supervisor(string)
	int raise;         //raise(int)
	int experience;    //years of experience(int)
};

