#include "Rectangle.h"

void Rectangle::setLength(int length) {
    Rectangle::length = length;
}

void Rectangle::setWidth(int width) {
    Rectangle::width = width;
}
