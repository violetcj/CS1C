#include "Triangle.h"

void Triangle::setHyp(double hyp) {
    Triangle::hyp = hyp;
}

void Triangle::setHeight(double height) {
    Triangle::height = height;
}

void Triangle::setBase(double base) {
    Triangle::base = base;
}
